import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { GridModule } from '@syncfusion/ej2-angular-grids';
import {
  CommandColumnService, 
  CommandModel,SortService, 
  FilterService, 
  GroupService ,
  FreezeService, 
  ResizeService, 
  GridComponent,
  EditService, 
  ToolbarService, 
  PageService, 
  NewRowPosition,
  DialogEditEventArgs, 
  SaveEventArgs 

} from '@syncfusion/ej2-angular-grids';
import { DataUtil } from '@syncfusion/ej2-data';
import { Dialog } from '@syncfusion/ej2-angular-popups';
import { AppComponent } from './app.component';
import { FreezeComponent } from './freeze/freeze.component';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { GridComponent1 } from './grid/grid.component';
import { NumericTextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { Browser } from '@syncfusion/ej2-base';
import { ChangeEventArgs, DropDownListComponent } from '@syncfusion/ej2-angular-dropdowns';
import { InlineEditingComponent } from './inline-editing/inline-editing.component';
import { DialogEditComponent } from './dialog-edit/dialog-edit.component';
import { CommandcolumneditComponent } from './commandcolumnedit/commandcolumnedit.component';
import { ReactiveeditComponent } from './reactiveedit/reactiveedit.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DetailsDataComponent } from './details-data/details-data.component';
@NgModule({
  declarations: [
    AppComponent,
    FreezeComponent,
    HeaderComponent,
    GridComponent1,
    InlineEditingComponent,
        NumericTextBoxComponent,
        DropDownListComponent,
        DialogEditComponent,
        CommandcolumneditComponent,
        ReactiveeditComponent,
        DetailsDataComponent
  ],
  imports: [
    BrowserModule,
    GridModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
       { path:'',pathMatch:'full',redirectTo:'header' },
       { path:'header',component:HeaderComponent,
       children:[
        { path:'',pathMatch:'full',redirectTo:'grid'},
        { path:'grid',component:GridComponent1 },
        { path:'freeze',component:FreezeComponent },
        { path:'inlineEdit',component:InlineEditingComponent },
        { path:'dialogEdit',component:DialogEditComponent },
        { path:'cmd_col_edit',component:CommandcolumneditComponent },
        { path:'reactive_edit',component:ReactiveeditComponent },
        { path:'detailsData',component:DetailsDataComponent }
       ] }
      ])
  ],
  providers: [PageService, SortService, FilterService, GroupService,FreezeService,ResizeService,CommandColumnService],
  bootstrap: [AppComponent]
})
export class AppModule { }
