import { Component, OnInit ,ViewChild} from '@angular/core';
import { NumericTextBoxComponent } from '@syncfusion/ej2-angular-inputs';
import { FreezeService, ResizeService, GridComponent, SortService } from '@syncfusion/ej2-angular-grids';
import { Browser } from '@syncfusion/ej2-base';
import { orderDetails } from '../data'
@Component({
  selector: 'app-freeze',
  templateUrl: './freeze.component.html',
  styleUrls: ['./freeze.component.css'],
    providers: [FreezeService, ResizeService, SortService]
})
export class FreezeComponent implements OnInit {

   @ViewChild('grid')
    public grid: GridComponent;
    @ViewChild('rows')
    public rows: NumericTextBoxComponent;
    @ViewChild('columns')
    public columns: NumericTextBoxComponent;
    public data: Object[] = [];
    columnValue: number = Browser.isDevice ? 1 : 2;
    //After clicking 'Set' button, the `frozenRows` and `frozenColumns` values will be updated in Grid.
    btnClick() {
        this.grid.frozenRows = this.rows.value;
        this.grid.frozenColumns = this.columns.value;
    }

    ngOnInit(): void {
        this.data = orderDetails;
    }

}
