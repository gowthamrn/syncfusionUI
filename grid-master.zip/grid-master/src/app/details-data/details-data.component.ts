import { Component, OnInit, Inject, ViewEncapsulation  } from '@angular/core';
import { DetailRowService } from '@syncfusion/ej2-angular-grids';
import { Internationalization } from '@syncfusion/ej2-base';
import { orderDetails } from '../data'

let instance: Internationalization = new Internationalization();

@Component({
  selector: 'app-details-data',
  templateUrl: './details-data.component.html',
  styleUrls: ['./details-data.component.css'],
    providers: [DetailRowService],
    encapsulation: ViewEncapsulation.None
})
export class DetailsDataComponent implements OnInit {
 public data: any;

    constructor() {}

    ngOnInit(): void {
        this.data = orderDetails;
    }

   
}

export interface DateFormat extends Window {
    format?: Function;
}